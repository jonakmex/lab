# Error Codes & Handling

This service validates incoming **card personalization** requests and either:
- **Publishes an error event** to the outbound topic when validation fails, or
- **Updates DB + re-uploads the (encrypted) payload to S3 (processed/)** when validation succeeds.

All error events are published to **PENDING** (outbound error topic/routing key) using **Avro** (`org.apache.avro:avro-tools:1.12.0`).  
For exact Avro subject/Schema Registry URL, see [Configuration](./Configuration.md).

> **Log context (recommended):** include `correlationId`, `packageUniqueId`, `kafkaOffset`, `s3Key`, `validationStage`.  
> **Metric context (recommended):** `error_code`, `rule_name`, `env`, `region`.

---

## Error Catalog

| Code | Title | Message | Typical Cause | Signals (Logs/Metrics) | Runbook (Support Actions) |
|---|---|---|---|---|---|
| **9001** | Decryption failure | `Unable to decrypt request payload.` | Invalid/expired keys, wrong KMS alias/config, corrupt payload, wrong ciphertext format. | **Logs:** `error_code=9001` and stack trace from `JWECryptoUtil`/KMS client. **Metrics:** spike in `validation_errors_total{error_code="9001"}`. | 1) Verify **kms-config** (active key paths/aliases). 2) Check the **secrets mount** and permissions. 3) Validate payload **envelope (JWE/JWS) format**. 4) Reprocess after fixing keys. 5) If persistent, **escalate to Security/KMS** with `correlationId`. |
| **9002** | Missing mandatory fields | `Mandatory attributes are missing in the package.` | Payload missing required attributes; schema drift between producer and this service; upstream mapping issue. | **Logs:** `error_code=9002`, list of missing fields, rule name. **Metrics:** increase in `validation_errors_total{error_code="9002"}`. | 1) Identify **which fields** are missing from logs. 2) Confirm current **Avro/JSON schema** and mapping in `cardpersoapi`. 3) Coordinate with producer to fix serialization. 4) If transient, request **replay** of corrected message. |
| **9003** | Business rule violation | `Request Payload processing failed.` | One or more business rules failed (e.g., invalid status, product code, personalization constraints). | **Logs:** `error_code=9003`, `rule_name`, offending values. **Metrics:** `validation_errors_total{error_code="9003", rule_name="..."}`. | 1) From logs, identify **rule_name** and **condition**. 2) Check reference data/config driving the rule. 3) If configuration-driven, correct config and reprocess. 4) If code defect, **create ticket** with sample payload (redacted) and `correlationId`. |
| **9006** | Duplicate request | `PackageUniqueId must be unique. Value received: ###` | Re-ingestion or duplicate send; violation of uniqueness (DB unique index / in-memory dedupe). | **Logs:** `error_code=9006`, `packageUniqueId`, conflict source (DB constraint / cache hit). **Metrics:** `validation_errors_total{error_code="9006"}`. | 1) Confirm **idempotency** strategy (DB unique constraint on `package_unique_id` or dedupe store). 2) Verify if the **original message** was already processed (check DB row & S3 processed/). 3) If upstream sent duplicates, align on **idempotent producer** pattern or filtering. |

---

## Publishing Behavior (Failures)

- **Destination (topic/routing key):** **PENDING**  
- **Format:** Avro (schema **PENDING** / subject **PENDING** / Schema Registry URL **PENDING**)  
- **Payload (recommended fields):**  
  - `errorCode` (e.g., `9002`)  
  - `errorMessage` (human-readable)  
  - `packageUniqueId`  
  - `correlationId`  
  - `timestamp` (UTC)  
  - `details` (list of missing fields / rule name / stack summary)  
  - `sourceService` (e.g., `card-perso-validator-svc`)  
  - `originalS3Key` (if applicable)

> **Note:** Keep PII out of error payloads. Include only IDs and technical context.

---

## Success Path (Reference)

When validation succeeds:
1. Update **PostgreSQL** (`cardpersodb`) with the new status (exact table/schema: **PENDING**).  
2. Re-encrypt payload and upload to **S3** under **processed/** (exact key pattern: **PENDING**).  
3. (Optional) Publish a **success status** event (if required by downstreams): **PENDING**.

---

## Retries, DLQ & Idempotency

- **Consumer retry policy:** **PENDING** (e.g., max attempts, backoff).  
- **DLQ / Parking lot:** **PENDING** (topic/queue).  
- **Idempotency key:** `packageUniqueId` (expected).  
- **DB uniqueness:** **PENDING** (table/column, constraint name).  
- **At-least-once vs. exactly-once semantics:** **PENDING** (document effective behavior).

> **Recommendation:**  
> - Log `correlationId` consistently across retry attempts.  
> - Guard success path with idempotent DB write + S3 object keying to avoid duplicate “processed” artifacts.  
> - If Schema Registry is used, pin reader schema compatibility (e.g., `BACKWARD`).

---

## Observability (Operations)

- **Logs:** Structured JSON, include `error_code`, `correlationId`, `packageUniqueId`, `stage`.  
- **Metrics (Prometheus-style examples):**  
  - `validation_requests_total{env,region}`  
  - `validation_success_total{env,region}`  
  - `validation_errors_total{env,region,error_code}`  
  - `decrypt_duration_seconds_bucket`  
  - `s3_fetch_duration_seconds_bucket`  
  - `db_update_duration_seconds_bucket`  
- **Alerts (examples):**  
  - High error rate for `error_code=9001` (potential KMS/secrets incident).  
  - Sustained `9002` spikes (schema/mapping drift).  
  - Sudden `9006` increase (duplicate storm upstream).  

---

## Runbook Quicklinks

- **KMS / JWECryptoUtil config:** see [`kms-config` in Configuration](./Configuration.md#encryption-jwecryptoutil--kms-config)  
- **S3 paths & prefixes:** see [AWS S3 in Configuration](./Configuration.md#aws-s3)  
- **Avro schema / Schema Registry:** see [Outbound Errors / Avro](./Configuration.md#kafka-outbound-errors--avro)  
- **DB connection & schema:** see [Database](./Configuration.md#database-postgresql)
