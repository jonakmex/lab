**Card Perso Validator Service — Wiki**

*Getting Started*
- [[Home (Overview)|README]]
- [[How to Run Locally]]

*Design*
- [[Architecture]]
- [[Application Workflow|Application-Workflow]]
- [[Integration Points|Integration-Points]]

*Ops & Config*
- [[Configuration]]
- [[Deployment]]
- [[Error Codes & Handling|Error-Codes-and-Handling]]
- [[Observability]]
