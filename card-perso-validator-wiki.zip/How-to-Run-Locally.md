# How to Run Locally

> Goal: run the **Card Perso Validator Service** on your laptop with local Kafka, PostgreSQL, and S3/KMS emulation (LocalStack).  
> Profile used: `local`

---

## Prerequisites

- JDK **21**
- Docker & Docker Compose
- Git, Bash
- Gradle Wrapper (`./gradlew`)
- (Optional) `awscli` or `awslocal` for LocalStack utilities

---

## Quickstart

```bash
# 1) Start infra (Kafka, Postgres, LocalStack)
docker compose -f docker-compose.local.yml up -d

# 2) Create Kafka topics (input/error) and verify
docker exec -it kafka kafka-topics.sh --create --topic business.direct-banking.cross-product.production-management.card-fulfillment-processing.validation --bootstrap-server localhost:9092 --if-not-exists
docker exec -it kafka kafka-topics.sh --create --topic business.direct-banking.cross-product.production-management.production-status.status-update --bootstrap-server localhost:9092 --if-not-exists
docker exec -it kafka kafka-topics.sh --list --bootstrap-server localhost:9092

# 3) Prepare S3 bucket & prefixes on LocalStack
awslocal s3 mb s3://PENDING
awslocal s3api put-object --bucket PENDING --key incoming/
awslocal s3api put-object --bucket PENDING --key processed/

# (Optional) 4) Create a KMS key (LocalStack)
awslocal kms create-key --description "local dev key" --key-usage ENCRYPT_DECRYPT

# 5) Run DB migrations on startup (Flyway is auto-enabled in application-local.yml)
#    or run via Gradle if you have plugin configured (optional)

# 6) Run the app
./gradlew bootRun --args='--spring.profiles.active=local'
# or
./gradlew clean build && java -jar build/libs/card-perso-validator-svc-*.jar --spring.profiles.active=local
```

---

## Docker Compose (save as `docker-compose.local.yml`)

```yaml
version: "3.9"

services:
  zookeeper:
    image: bitnami/zookeeper:3.9
    container_name: zookeeper
    environment:
      - ALLOW_ANONYMOUS_LOGIN=yes
    ports:
      - "2181:2181"

  kafka:
    image: bitnami/kafka:3.7
    container_name: kafka
    depends_on:
      - zookeeper
    environment:
      - KAFKA_BROKER_ID=1
      - KAFKA_CFG_ZOOKEEPER_CONNECT=zookeeper:2181
      - KAFKA_CFG_LISTENERS=PLAINTEXT://:9092
      - KAFKA_CFG_ADVERTISED_LISTENERS=PLAINTEXT://localhost:9092
      - KAFKA_CFG_AUTO_CREATE_TOPICS_ENABLE=false
      - ALLOW_PLAINTEXT_LISTENER=yes
    ports:
      - "9092:9092"

  postgres:
    image: postgres:15
    container_name: postgres
    environment:
      - POSTGRES_DB=cardpersodb
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=postgres
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U postgres -d cardpersodb"]
      interval: 5s
      timeout: 5s
      retries: 10

  localstack:
    image: localstack/localstack:3
    container_name: localstack
    environment:
      - SERVICES=s3,kms
      - DEFAULT_REGION=us-east-1
      - EDGE_PORT=4566
    ports:
      - "4566:4566"
    volumes:
      - "localstack-data:/var/lib/localstack"
      - "/var/run/docker.sock:/var/run/docker.sock"

volumes:
  localstack-data:
```

---

## Local Application Configuration

Create `src/main/resources/application-local.yml`:

```yaml
spring:
  application:
    name: card-perso-validator-svc
  datasource:
    url: jdbc:postgresql://localhost:5432/cardpersodb
    username: postgres
    password: postgres
    hikari:
      maximum-pool-size: 10
  jpa:
    properties:
      hibernate:
        default_schema: PENDING
  flyway:
    enabled: true
    baseline-on-migrate: true
    # locations: classpath:db/migration  # adjust if needed

server:
  port: 8080

logging:
  level:
    root: INFO
    com.discover.cardfp: DEBUG

management:
  endpoints:
    web:
      exposure:
        include: health,info,prometheus
  endpoint:
    health:
      probes:
        enabled: true

kafka:
  bootstrap-servers: localhost:9092
  consumer:
    group-id: card-perso-validator-svc-local
    enable-auto-commit: false
    max-poll-records: 100
  topics:
    input: business.direct-banking.cross-product.production-management.card-fulfillment-processing.validation
    error: business.direct-banking.cross-product.production-management.production-status.status-update

aws:
  region: us-east-1
  s3:
    bucket: PENDING
    prefix:
      incoming: incoming/
      processed: processed/
  secrets:
    file: /var/secrets/s3/s3cred.properties

cloud:
  aws:
    endpoint: http://localhost:4566
    s3:
      endpoint: http://localhost:4566
    kms:
      endpoint: http://localhost:4566

schema:
  registry:
    url: PENDING
  avro:
    subject: PENDING

kms-config:
  location: PENDING
  jweCertificationActive: PENDING
  jweCertificationExpiring: PENDING
  jweCertificationExpired: PENDING
  symetricKeyLocationActive: PENDING
  symetricKeyLocationExpired: PENDING

encryption:
  algorithm: PENDING
  rotation:
    policy: PENDING

rest:
  authapi:
    base-url: PENDING
    timeout-ms: 3000
  cardpersoapi:
    base-url: PENDING
    timeout-ms: 3000
```

> If the app reads AWS credentials from a file (`/var/secrets/s3/s3cred.properties`), for local dev you can place a file there with dummy values or configure standard `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY` environment variables.

---

## Seed Data / Utilities

### Create a sample encrypted object (placeholder)

```bash
# Put a dummy file (you can replace with an actually encrypted JWE payload)
echo '{"packageUniqueId":"demo-001","payload":"ENCRYPTED_PLACEHOLDER"}' > sample.jwe
awslocal s3 cp sample.jwe s3://PENDING/incoming/2025-08-20/demo-001.json.jwe
```

### Publish a test metadata record to the input topic

Using `kcat` (Docker):

```bash
docker run -it --network host --rm edenhill/kcat:1.7.1   -P -b localhost:9092 -t business.direct-banking.cross-product.production-management.card-fulfillment-processing.validation <<EOF
{"correlationId":"11111111-1111-1111-1111-111111111111","packageUniqueId":"demo-001","s3Key":"incoming/2025-08-20/demo-001.json.jwe"}
EOF
```

---

## Running Tests & Coverage

```bash
./gradlew test
./gradlew jacocoTestReport
# HTML report: build/reports/jacoco/test/html/index.html
```

---

## Common Troubleshooting

- **Cannot connect to Kafka**  
  Ensure `kafka` container is up and listening on `localhost:9092`. On some systems, advertised listener must be `PLAINTEXT://localhost:9092`.

- **S3/KMS endpoint timeouts**  
  Check LocalStack at `http://localhost:4566/health`. Confirm endpoints are set in `application-local.yml`.

- **DB migration errors (Flyway)**  
  Confirm schema name and `flyway.locations`. If starting fresh, set `baseline-on-migrate: true`.

- **Decryption failures (9001) in local**  
  If you are not truly encrypting JWE in dev, you can:  
  - Stub the decrypt step in `local` profile **PENDING** (feature flag), or  
  - Use LocalStack KMS to create a key and wire a real (dev) decryption path.

---

## Clean Up

```bash
docker compose -f docker-compose.local.yml down -v
```
