# Architecture

The diagram below shows the main components and data flow of the Card Perso Validator Service.

```mermaid
flowchart LR
    subgraph Inbound
      KAFKA[Kafka Topic\nbusiness.direct-banking.cross-product.production-management.card-fulfillment-processing.validation]
    end

    subgraph App[Card Perso Validator Service<br/>com.discover.cardfp.CardPersoValidatorSvcApplication]
      RT1[REST Template:\ncardpersoapi]
      RT2[REST Template:\nauthapi]
      AWSSECRETS[/AWS Secrets file\n/var/secrets/s3/s3cred.properties/]
      KMS[KMS / JWECryptoUtil\n(kms-config)]
      VALID[Validation Engine\nBusiness rules]
      AVRO[Avro schema\n(org.apache.avro:avro-tools 1.12.0)]
      FLYWAY[Flyway DB Migrations]
    end

    subgraph AWS[AWS S3]
      S3IN[(Encrypted Request\n(s3://.../incoming/...))]
      S3PROCESSED[(Encrypted Request\nwith status=SUCCESS\nmoved to processed/)]
    end

    subgraph Data[PostgreSQL\ncardpersodb]
      DB[(Update status/records)]
    end

    subgraph Outbound
      ERRQ[Kafka/Routing Key\nbusiness.direct-banking.cross-product.production-management.production-status.status-update]
    end

    KAFKA -->|Metadata| App
    App -->|Fetch object| S3IN
    App -->|Use creds| AWSSECRETS
    App -->|Decrypt/Encrypt| KMS

    App -->|Decrypt payload| VALID
    RT2 --> App
    RT1 --> App

    VALID -->|OK| DB
    VALID -->|OK| S3PROCESSED
    VALID -->|ERROR| AVRO
    AVRO -->|Publish error event| ERRQ

    FLYWAY --- DB
```
