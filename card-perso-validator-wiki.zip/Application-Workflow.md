# Application Workflow

This service validates **card personalization** requests consumed from Kafka, reads the full (encrypted) payload from **AWS S3**, decrypts it, runs validations, and then:
- On **success**: updates **PostgreSQL** (`cardpersodb`), re-encrypts the payload, and stores it under **processed/** in S3.
- On **failure**: publishes an **Avro** error event to the outbound topic `business.direct-banking.cross-product.production-management.production-status.status-update`.

> **Main class:** `com.discover.cardfp.CardPersoValidatorSvcApplication`  
> **AWS Secrets file (S3 creds):** `/var/secrets/s3/s3cred.properties`  
> **Encryption:** `JWECryptoUtil` with **kms-config** (see *Configuration*)  
> **REST clients:** `cardpersoapi`, `authapi` (Spring RestTemplate)

---

## Sequence (High-level)

```mermaid
sequenceDiagram
    autonumber
    participant U as Upstream Producer
    participant K as Kafka Topic<br/>business...card-fulfillment-processing.validation
    participant S as Card Perso Validator Svc
    participant A as authapi (REST)
    participant C as cardpersoapi (REST)
    participant S3 as AWS S3 (incoming/processed)
    participant KMS as JWECryptoUtil / KMS
    participant DB as PostgreSQL (cardpersodb)
    participant E as Outbound Topic<br/>business...production-status.status-update

    U->>K: Publish metadata (packageUniqueId, s3Key, correlationId, ...)
    K->>S: Consume record (metadata)
    Note over S: Extract IDs & s3 object key from metadata

    S->>S3: Get object (encrypted) from incoming/<PENDING>
    S->>KMS: Decrypt payload (JWE/JWS)
    alt Decryption fails
        S->>E: Publish error (code=9001, Avro)
        S-->>K: Commit/Retry per policy (PENDING)
    else Decryption ok
        S->>A: (Optional) Auth/Token/Ref data
        S->>C: (Optional) Lookup/Validate refs
        S->>S: Validate mandatory fields
        alt Missing fields
            S->>E: Publish error (code=9002, Avro)
        else All mandatory present
            S->>S: Validate business rules
            alt Rule violation
                S->>E: Publish error (code=9003, Avro)
            else Rules passed
                S->>DB: Check duplicate by packageUniqueId
                alt Duplicate found
                    S->>E: Publish error (code=9006, Avro)
                else Unique
                    S->>DB: Update status (e.g., VALIDATED) (table=PENDING)
                    S->>KMS: Re-encrypt payload
                    S->>S3: Put object to processed/<PENDING>
                    Note over S3: Move/copy & tag with status=SUCCESS
                end
            end
        end
    end
```

---

## Detailed Steps

1. **Consume metadata from Kafka**  
   - **Input topic**: `business.direct-banking.cross-product.production-management.card-fulfillment-processing.validation`  
   - Extract: `correlationId`, `packageUniqueId`, `s3Key` (or bucket+prefix), any other routing fields.

2. **Fetch encrypted payload from S3 (incoming)**  
   - **Bucket**: **PENDING**  
   - **Key pattern**: `incoming/<date>/<packageUniqueId>.json.jwe` (**PENDING**)  
   - **Auth**: credentials from `/var/secrets/s3/s3cred.properties` or IAM role (**PENDING**).

3. **Decrypt (JWECryptoUtil / KMS)**  
   - **kms-config** fields: `location`, `jweCertificationActive`, `jweCertificationExpiring`, `jweCertificationExpired`, `symetricKeyLocationActive`, `symetricKeyLocationExpired`.  
   - **Failure → 9001**: publish Avro error and follow retry/DLQ policy (**PENDING**).

4. **Validation – Mandatory fields**  
   - Ensure all required attributes are present per current schema (**PENDING schema ref**).  
   - **Failure → 9002** with field list in `details`.

5. **Validation – Business rules**  
   - Validate domain constraints (examples: product eligibility, status transitions, personalization limits, etc.).  
   - **Failure → 9003** including `rule_name` and failing condition in `details`.

6. **Duplicate check**  
   - Lookup by `packageUniqueId` in **PostgreSQL** (`cardpersodb`, table **PENDING**).  
   - **Failure → 9006** if already processed/exists.

7. **Success path**  
   - Update DB status (table/schema **PENDING**; suggested statuses **PENDING**).  
   - Re-encrypt payload and **write to S3** under `processed/` (key pattern **PENDING**).  
   - (Optional) Publish a **success event** (**PENDING**).

---

## Inputs & Outputs

| Stage | Input | Output |
|---|---|---|
| Kafka consume | Metadata record (topic above) | Internal processing request |
| S3 fetch | `s3://<bucket>/<incomingKey>` (encrypted) | Encrypted object bytes |
| Decrypt | Encrypted bytes + kms-config | JSON/XML payload (plaintext) |
| Validate | Plaintext payload + ref data | OK or error code (9001/9002/9003/9006) |
| DB update | `packageUniqueId`, status | Row updated/inserted |
| S3 processed | Plaintext → re-encrypted object | `s3://<bucket>/processed/<key>` |
| Error publish | Error context | Avro event to `...production-status.status-update` |

---

## Error Events (Avro) — Example

```json
{
  "sourceService": "card-perso-validator-svc",
  "correlationId": "<uuid>",
  "packageUniqueId": "<id>",
  "errorCode": "9002",
  "errorMessage": "Mandatory attributes are missing in the package",
  "details": {
    "missing": ["fieldA", "fieldB"],
    "rule_name": null
  },
  "originalS3Key": "incoming/2025-08-20/<id>.json.jwe",
  "timestamp": "2025-08-20T16:05:00Z",
  "env": "PENDING",
  "region": "PENDING"
}
```

> **PII:** do not include sensitive data; use identifiers and technical context only.

---

## Idempotency & Retries

- **Idempotency key:** `packageUniqueId` (enforced via DB unique constraint **PENDING**).  
- **Kafka semantics:** effectively **at-least-once**; ensure DB update + S3 write are idempotent.  
- **Retries/DLQ:** **PENDING** (max attempts, backoff, DLQ topic name).  
- **Offset commit:** commit only after terminal action (DB/S3/error publish) per policy **PENDING**.

**Recommendations**
- Write success path idempotently (check existing DB row and S3 processed key before write).  
- Include `correlationId` consistently in logs and events.  
- Guard against partial successes (e.g., DB updated but S3 failed) with compensating logic or reconciler **PENDING**.

---

## State Model (Statuses — Suggested, mark real ones as PENDING)

```mermaid
stateDiagram-v2
    [*] --> RECEIVED
    RECEIVED --> VALIDATING
    VALIDATING --> VALIDATED: All checks passed
    VALIDATING --> FAILED_DECRYPTION: 9001
    VALIDATING --> FAILED_MANDATORY: 9002
    VALIDATING --> FAILED_RULES: 9003
    VALIDATING --> DUPLICATE: 9006
    VALIDATED --> PROCESSED: S3 write confirmed
    FAILED_DECRYPTION --> [*]
    FAILED_MANDATORY --> [*]
    FAILED_RULES --> [*]
    DUPLICATE --> [*]
    PROCESSED --> [*]
```

> **DB schema/table names:** **PENDING** (e.g., `card_request(status, package_unique_id, updated_at, ...)`).

---

## Observability

- **Logs:** structured JSON including `correlationId`, `packageUniqueId`, `stage`, and `errorCode` (if any).  
- **Metrics (examples):**  
  - `validation_requests_total{env,region}`  
  - `validation_success_total{env,region}`  
  - `validation_errors_total{env,region,error_code}`  
  - `s3_fetch_duration_seconds_bucket`  
  - `decrypt_duration_seconds_bucket`  
  - `db_update_duration_seconds_bucket`  
- **Alerts:** spike of `9001` (KMS/keys), `9002` (schema drift), `9006` (duplicate storm).
