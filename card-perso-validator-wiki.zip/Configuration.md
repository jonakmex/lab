# Configuration

## Kafka (Inbound & Consumer)
| Key | Description | Value |
|---|---|---|
| `kafka.bootstrap-servers` | Kafka brokers list | **PENDING** |
| `kafka.consumer.group-id` | Consumer group id | **PENDING** |
| `kafka.input.topic` | Inbound topic/routing key | **PENDING** |
| `kafka.max-poll-records` | Max records per poll | **PENDING** |
| `kafka.enable-auto-commit` | Auto commit toggle | **PENDING** |
| `kafka.dlq.topic` | Dead-letter topic (if any) | **PENDING** |

## Kafka (Outbound Errors / Avro)
| Key | Description | Value |
|---|---|---|
| `kafka.error.topic` | Outbound error topic/routing key | **PENDING** |
| `avro.schema.subject` | Avro subject (if using Schema Registry) | **PENDING** |
| `schema.registry.url` | Schema Registry URL | **PENDING** |

## AWS S3
| Key | Description | Value |
|---|---|---|
| `aws.s3.bucket` | Bucket name | **PENDING** |
| `aws.s3.prefix.incoming` | Prefix for incoming objects | **PENDING** |
| `aws.s3.prefix.processed` | Prefix for processed objects | **PENDING** |
| `aws.secrets.file` | Path to S3 creds file | **PENDING** |
| `aws.iam.role` | IAM role / profile (if any) | **PENDING** |

## Database (PostgreSQL)
| Key | Description | Value |
|---|---|---|
| `spring.datasource.url` | JDBC URL | **PENDING** |
| `spring.datasource.username` | DB username | **PENDING** |
| `spring.datasource.password` | DB password | **PENDING** |
| `spring.datasource.hikari.maximum-pool-size` | Pool size | **PENDING** |
| `spring.jpa.database` | Database name (expected: `cardpersodb`) | **PENDING** |
| `spring.jpa.properties.hibernate.default_schema` | DB schema | **PENDING** |
| `flyway.locations` | Flyway migration locations | **PENDING** |
| `flyway.baselineOnMigrate` | Flyway baseline if needed | **PENDING** |

## Encryption (JWECryptoUtil / kms-config)
| Key | Description | Value |
|---|---|---|
| `kms-config.location` | KMS config location | **PENDING** |
| `kms-config.jweCertificationActive` | JWE active cert path/id | **PENDING** |
| `kms-config.jweCertificationExpiring` | JWE expiring cert path/id | **PENDING** |
| `kms-config.jweCertificationExpired` | JWE expired cert path/id | **PENDING** |
| `kms-config.symetricKeyLocationActive` | Symmetric key (active) | **PENDING** |
| `kms-config.symetricKeyLocationExpired` | Symmetric key (expired) | **PENDING** |
| `encryption.algorithm` | JWE/JWS algorithm | **PENDING** |
| `encryption.rotation.policy` | Key rotation policy | **PENDING** |

## Application
| Key | Description | Value |
|---|---|---|
| `server.port` | HTTP port | **PENDING** |
| `logging.level.root` | Global log level | **PENDING** |
| `management.endpoints.web.exposure.include` | Exposed actuator endpoints | **PENDING** |
| `management.endpoint.health.probes.enabled` | K8s probes | **PENDING** |
| `spring.profiles.active` | Active profile(s) | **PENDING** |
| `feature.flags.*` | Feature toggles | **PENDING** |

---

## Example `application.yml` (placeholders)

```yaml
spring:
  application:
    name: card-perso-validator-svc
  profiles:
    active: PENDING
  datasource:
    url: PENDING
    username: PENDING
    password: PENDING
    hikari:
      maximum-pool-size: PENDING
  jpa:
    properties:
      hibernate:
        default_schema: PENDING

server:
  port: PENDING

logging:
  level:
    root: PENDING

management:
  endpoints:
    web:
      exposure:
        include: PENDING
  endpoint:
    health:
      probes:
        enabled: PENDING

kafka:
  bootstrap-servers: PENDING
  consumer:
    group-id: PENDING
    enable-auto-commit: PENDING
    max-poll-records: PENDING
  input:
    topic: PENDING
  error:
    topic: PENDING
  dlq:
    topic: PENDING

schema:
  registry:
    url: PENDING
  avro:
    subject: PENDING

aws:
  s3:
    bucket: PENDING
    prefix:
      incoming: PENDING
      processed: PENDING
  secrets:
    file: PENDING
  iam:
    role: PENDING

kms-config:
  location: PENDING
  jweCertificationActive: PENDING
  jweCertificationExpiring: PENDING
  jweCertificationExpired: PENDING
  symetricKeyLocationActive: PENDING
  symetricKeyLocationExpired: PENDING

encryption:
  algorithm: PENDING
  rotation:
    policy: PENDING

feature:
  flags:
    example-flag: PENDING
```
