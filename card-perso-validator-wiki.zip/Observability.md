# Observability

This page defines **logs, metrics, traces, and alerts** for the Card Perso Validator Service. Values that vary by environment are marked **PENDING**.

---

## Actuator Endpoints

- Liveness: `/actuator/health/liveness`
- Readiness: `/actuator/health/readiness`
- Health: `/actuator/health`
- Prometheus: `/actuator/prometheus`

> Ensure these are exposed according to your security policy (ingress/network policy restricted).

---

## Structured Logging (JSON)

**Goals:** fast incident triage, easy correlation, no PII.

**Required MDC fields (log context):**
- `correlationId`
- `packageUniqueId`
- `stage` (e.g., `consume`, `s3_fetch`, `decrypt`, `validate_mandatory`, `validate_rules`, `db_update`, `s3_put`, `publish_error`)
- `errorCode` (only on failures: 9001/9002/9003/9006)
- `env`, `region`

**Example (INFO):**
```json
{
  "ts":"2025-08-20T16:15:20.113Z",
  "level":"INFO",
  "logger":"com.discover.cardfp.validation.Validator",
  "message":"Validation passed",
  "correlationId":"e2e2f7b2-...",
  "packageUniqueId":"pkg-123",
  "stage":"validate_rules",
  "env":"PENDING",
  "region":"PENDING",
  "durationMs": 42
}
```

**Example (ERROR 9001):**
```json
{
  "ts":"2025-08-20T16:15:23.501Z",
  "level":"ERROR",
  "logger":"com.discover.cardfp.crypto.JWECryptoUtil",
  "message":"Unable to decrypt request payload",
  "correlationId":"e2e2f7b2-...",
  "packageUniqueId":"pkg-123",
  "stage":"decrypt",
  "errorCode":"9001",
  "exception":"javax.crypto.BadPaddingException",
  "env":"PENDING",
  "region":"PENDING"
}
```

**Guidelines**
- Do **not** log payload/PII. Log identifiers and technical context only.
- Use **WARN** for retriable/transient and **ERROR** for terminal failures.
- Include durations (ms) for major stages.
- Rotate/retain logs per platform policy (**PENDING**).

---

## Metrics (Micrometer/Prometheus)

### Business/Flow Metrics
- `validation_requests_total{env,region}` — increment on each consumed record.
- `validation_success_total{env,region}` — success path completion.
- `validation_errors_total{env,region,error_code}` — label with `9001|9002|9003|9006`.
- `dedupe_hits_total{env,region}` — increment when duplicate detected (9006).

### Latency Histograms
- `s3_fetch_duration_seconds_bucket{env,region}`
- `decrypt_duration_seconds_bucket{env,region}`
- `validate_duration_seconds_bucket{env,region}`
- `db_update_duration_seconds_bucket{env,region}`
- `s3_put_duration_seconds_bucket{env,region}`
- `publish_error_duration_seconds_bucket{env,region}`

> Configure reasonable buckets, e.g., `[0.01, 0.05, 0.1, 0.25, 0.5, 1, 2, 5]` seconds (**PENDING**).

### Platform/JVM
- `jvm_memory_used_bytes`, `jvm_gc_pause_seconds_*`, `jvm_threads_live`
- `process_cpu_usage`, `system_load_average_1m`
- `http_server_requests_seconds_*` (if any HTTP endpoints used by ops)

### Kafka
- **Consumer lag**: Use Kafka Lag Exporter/Burrow or JMX Exporter.
- Producer errors (for outbound error events) via client metrics or JMX.

**Recommended common tags:** `env`, `region`, `service="card-perso-validator-svc"`

---

## Alerts (Prometheus-style examples)

> Replace `job`/`namespace`/`service` selectors with your labels. Thresholds are **PENDING**.

### Decryption failures spike (9001)
```yaml
- alert: CpvDecryptionFailuresHigh
  expr: sum(rate(validation_errors_total{error_code="9001"}[5m])) > PENDING
  for: 10m
  labels:
    severity: critical
  annotations:
    summary: "Decryption failures (9001) are high"
    description: "Spike in 9001 suggests KMS/keys/secrets issue. Check JWECryptoUtil and kms-config."
```

### Mandatory fields errors spike (9002)
```yaml
- alert: CpvMissingMandatoryHigh
  expr: sum(rate(validation_errors_total{error_code="9002"}[10m])) > PENDING
  for: 15m
  labels:
    severity: warning
  annotations:
    summary: "Mandatory fields (9002) elevated"
    description: "Possible schema drift or upstream mapping issue."
```

### Duplicate surge (9006)
```yaml
- alert: CpvDuplicatesHigh
  expr: sum(rate(validation_errors_total{error_code="9006"}[10m])) > PENDING
  for: 15m
  labels:
    severity: warning
  annotations:
    summary: "Duplicate requests (9006) elevated"
    description: "Check idempotency and upstream duplicate sends."
```

### Consumer not processing
```yaml
- alert: CpvNoConsumption
  expr: rate(validation_requests_total[10m]) == 0
  for: 15m
  labels:
    severity: critical
  annotations:
    summary: "No records consumed in 15m"
    description: "Consumer may be down or partition assignment lost."
```

### Readiness failing
```yaml
- alert: CpvReadinessFailing
  expr: probe_success{endpoint="readiness"} == 0
  for: 5m
  labels:
    severity: critical
  annotations:
    summary: "Readiness failing"
    description: "Pods are not ready. Check logs and dependencies."
```

### Latency SLO breach (example: decrypt p95)
```yaml
- alert: CpvDecryptLatencyHigh
  expr: histogram_quantile(0.95, sum(rate(decrypt_duration_seconds_bucket[5m])) by (le)) > PENDING
  for: 10m
  labels:
    severity: warning
  annotations:
    summary: "Decrypt p95 too high"
    description: "Investigate KMS performance or payload sizes."
```

---

## Tracing (Optional but Recommended)

- Instrument with **OpenTelemetry** (Spring Boot autoconfig).
- Exporter: OTLP gRPC to `PENDING_OTLP_ENDPOINT`.
- Propagate `correlationId` via headers:
  - Kafka: use record headers (e.g., `X-Correlation-Id`).
  - REST: `X-Correlation-Id`.
- Sample config (YAML, pseudocode):
```yaml
management:
  tracing:
    sampling:
      probability: 0.1   # PENDING
otel:
  exporter:
    otlp:
      endpoint: PENDING
```

---

## Dashboards (Grafana - suggestions)

- **Overview panel**
  - Requests: `validation_requests_total`
  - Success rate: success / (success+errors)
  - Error rate by code: stacked series by `error_code`
- **Latency panel**
  - p50/p95/p99 for decrypt, s3_fetch, db_update
- **Kafka**
  - Consumer lag per partition
  - Records consumed rate
- **Resources**
  - CPU, memory, GC pauses
- **Alerts table**
  - Active alerts with annotations

---

## SLIs/SLOs (Proposed)

- **Availability SLO**: >= 99.9% monthly (readiness up / successful processing) — PENDING formula details.
- **Success Latency SLO (p95)**: end-to-end validation time < PENDING seconds.
- **Error Publish Latency SLO (p95)**: < PENDING seconds for failure path.
- **Error Budget**: PENDING.

---

## Runbook Shortcuts

- 9001/9002/9003/9006 actions: see [Error Codes & Handling](./Error-Codes-and-Handling.md)
- Check DB row for `packageUniqueId`: PENDING table/schema
- Check S3 object location: `incoming/` vs `processed/`
- Verify Schema Registry compatibility (if used): PENDING

---

## Security & Compliance

- Logs must not contain PII or secrets.
- Ensure audit trails for changes to `kms-config` and keys.
- Retention: PENDING days (per environment policy).
