# Table of Contents

## Getting Started
- [Home (Overview)](README.md)
- [How to Run Locally](How-to-Run-Locally.md)

## Design
- [Architecture](Architecture.md)
- [Application Workflow](Application-Workflow.md)
- [Integration Points](Integration-Points.md)

## Ops & Config
- [Configuration](Configuration.md)
- [Deployment](Deployment.md)
- [Error Codes & Handling](Error-Codes-and-Handling.md)
- [Observability](Observability.md)
