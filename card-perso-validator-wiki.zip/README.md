# Card Perso Validator Service — Wiki (Tech/Support)

This service is part of the **card personalization** platform. It consumes **request metadata** from Kafka, retrieves the **encrypted** full payload from **AWS S3**, decrypts it, validates **mandatory fields** and **business rules**, and then:
- On **success**: updates **PostgreSQL** (`cardpersodb`), re-encrypts the payload, stores it under `processed/` in S3.
- On **failure**: publishes an **Avro** error event to the outbound topic.

> **Main class:** `com.discover.cardfp.CardPersoValidatorSvcApplication`  
> **Runtime:** Java 21 - Spring Boot 3.5.4 (Tomcat 11.0.9)  
> **Build:** Gradle - JaCoCo - Lombok 1.18.36 - MapStruct 1.6.3  
> **Deploy:** Helm - Flyway  
> **Crypto:** `JWECryptoUtil` with `kms-config`  
> **REST clients:** `cardpersoapi`, `authapi`  
> **Inbound topic:** `business.direct-banking.cross-product.production-management.card-fulfillment-processing.validation`  
> **Outbound (errors):** **PENDING** (confirm topic/routing key)

---

## Table of Contents
- [Architecture](./Architecture.md)
- [Application Workflow](./Application-Workflow.md)
- [Integration Points](./Integration-Points.md)
- [Configuration](./Configuration.md)
- [Error Codes & Handling](./Error-Codes-and-Handling.md)
- [Deployment](./Deployment.md)
- [How to Run Locally](./How-to-Run-Locally.md)
- [Observability](./Observability.md)
- [Ownership & Contacts](#ownership--contacts)

---

## Quick Overview Diagram

```mermaid
flowchart LR
  KAFKA[Kafka: validation metadata] --> APP[Card Perso Validator Svc]
  APP -->|get object| S3IN[(S3 incoming/ encrypted)]
  APP -->|decrypt| KMS[JWECryptoUtil / KMS]
  APP -->|validate| RULES[Mandatory + Business Rules]
  RULES -->|OK| DB[(PostgreSQL: cardpersodb)]
  RULES -->|OK| S3PROC[(S3 processed/ encrypted)]
  RULES -->|ERROR (Avro)| ERRTOPIC[Kafka: status update (errors)]
```

---

## Responsibilities (Scope)

- **Consume** metadata events from Kafka and **fetch** full payload from S3.
- **Decrypt / Encrypt** payloads using `JWECryptoUtil` and `kms-config`.
- **Validate** schema presence and domain rules.
- **Publish** standardized **error** events (Avro) on failures.
- **Update** DB status and **persist** success artifacts to S3 (`processed/`).
- **Idempotency** by `packageUniqueId` (DB uniqueness recommended).

Out of scope:
- Card printing, fulfillment routing, or delivery orchestration.
- Upstream enrichment or downstream success eventing (unless defined by env **PENDING**).

---

## Interfaces (At a Glance)

| Type | Name | Purpose | Notes |
|---|---|---|---|
| Kafka (in) | validation metadata | Start processing | Topic: `business.direct-banking.cross-product.production-management.card-fulfillment-processing.validation` |
| Kafka (out) | status update (errors) | Failure signaling (Avro) | Topic: **PENDING**; Schema Registry: **PENDING** |
| REST | `authapi` | Authn/Authz/refs | Base URL: **PENDING** |
| REST | `cardpersoapi` | Reference checks | Base URL: **PENDING** |
| S3 | `incoming/`, `processed/` | Payload storage | Bucket: **PENDING** |
| DB | `cardpersodb` | Status + dedupe | JDBC URL, schema: **PENDING** |

Full details in [Integration Points](./Integration-Points.md).

---

## Error Codes (Summary)

| Code | Meaning | Action |
|---|---|---|
| **9001** | Decryption failure | Check KMS/keys, secrets, envelope |
| **9002** | Missing mandatory fields | Align schema & producer mapping |
| **9003** | Business rule violation | Inspect rule name/condition |
| **9006** | Duplicate request | Verify idempotency & DB row |

Runbooks in [Error Codes & Handling](./Error-Codes-and-Handling.md).

---

## Build, Test & Coverage

```bash
./gradlew clean build
./gradlew test jacocoTestReport
# Report: build/reports/jacoco/test/html/index.html
```

Local setup, topics, and sample data in [How to Run Locally](./How-to-Run-Locally.md).

---

## Deployment (Helm)

- Chart skeleton, values, probes, HPA, PDB, ServiceMonitor, and Flyway strategies in [Deployment](./Deployment.md).
- Fill every **PENDING** with env-specific values before `helm upgrade --install`.

---

## Observability

See [Observability](./Observability.md). It includes logging schema, metrics catalog, example PrometheusRule alerts, and tracing recommendations.

---

## Ownership & Contacts

| Role | Team/Person | Contact |
|---|---|---|
| Product Owner | **PENDING** | **PENDING** |
| Tech Lead | **PENDING** | **PENDING** |
| On-call / SRE | **PENDING** | **PENDING** |
| Security/KMS | **PENDING** | **PENDING** |
| Data/DBA | **PENDING** | **PENDING** |

---

## Compliance & Security Notes

- **Secrets**: `/var/secrets/s3/s3cred.properties` (or IAM/IRSA). Never log or commit.  
- **PII**: Do not include PII in logs or error payloads.  
- **Schema**: Enforce backward-compatible evolution if using Schema Registry (**PENDING**).
