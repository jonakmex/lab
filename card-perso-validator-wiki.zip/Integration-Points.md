# Integration Points

This page documents all external integrations used by the **Card Perso Validator Service**. Values marked **PENDING** must be confirmed per environment.

---

## Summary

| Type | Name | Purpose | Protocol/Lib | Notes |
|---|---|---|---|---|
| REST | `authapi` | Obtain tokens / authn/authz / reference data | HTTP (RestTemplate) | Base URL **PENDING**; timeout & retry settings below |
| REST | `cardpersoapi` | Business lookups / reference validation | HTTP (RestTemplate) | Base URL **PENDING** |
| Kafka (in) | Validation metadata topic | Consume request metadata | Kafka client | Topic: `business.direct-banking.cross-product.production-management.card-fulfillment-processing.validation` |
| Kafka (out) | Status update (errors) | Publish error events (Avro) | Kafka client + Avro | Topic **PENDING** (confirm exact value); Schema Registry **PENDING** |
| S3 (in/out) | AWS S3 bucket | Read encrypted payload; write processed | AWS SDK | Bucket **PENDING**, prefixes: `incoming/`, `processed/` |
| DB | PostgreSQL `cardpersodb` | Persist request status & dedupe | JDBC / JPA | URL/credentials **PENDING** |
| Crypto | `JWECryptoUtil` + KMS | Decrypt/encrypt payloads | KMS/JWE | Config keys below |

---

## REST Clients

### `authapi`

| Field | Value |
|---|---|
| Base URL | **PENDING** |
| Auth | **PENDING** (e.g., client_credentials, mTLS, API key) |
| Timeout (connect/read) | **PENDING** (recommended: 2–3s connect, 3–5s read) |
| Retries | **PENDING** (recommended: 2 retries, exponential backoff) |
| Circuit breaker | **PENDING** (if using resilience4j) |
| Endpoints | **PENDING** |

**Sample config (YAML):**
```yaml
rest:
  authapi:
    base-url: PENDING
    timeout-ms: 3000
    # auth:
    #   client-id: PENDING
    #   client-secret: PENDING
    #   token-path: /oauth2/token
```

### `cardpersoapi`

| Field | Value |
|---|---|
| Base URL | **PENDING** |
| Auth | **PENDING** |
| Timeout (connect/read) | **PENDING** (recommended: 2–3s connect, 3–5s read) |
| Retries | **PENDING** |
| Circuit breaker | **PENDING** |
| Endpoints | **PENDING** |

**Sample config (YAML):**
```yaml
rest:
  cardpersoapi:
    base-url: PENDING
    timeout-ms: 3000
```

**RestTemplate factory (example):**
```java
@Bean
RestTemplate restTemplate(RestTemplateBuilder builder,
                          @Value("${rest.timeout-ms:3000}") int timeoutMs) {
  return builder
      .setConnectTimeout(Duration.ofMillis(timeoutMs))
      .setReadTimeout(Duration.ofMillis(timeoutMs))
      .additionalInterceptors((req, body, ex) -> {
        // add correlationId headers, auth headers, etc.
        return ex.execute(req, body);
      })
      .build();
}
```

> **Recommendation:** propagate `correlationId` to upstream REST calls via header (e.g., `X-Correlation-Id`).

---

## Kafka

### Inbound (consume)

| Field | Value |
|---|---|
| Topic | `business.direct-banking.cross-product.production-management.card-fulfillment-processing.validation` |
| Group ID | **PENDING** |
| Max poll records | **PENDING** |
| Auto commit | **PENDING** (recommended: false) |
| DLQ (if any) | **PENDING** |
| Offset strategy | Commit on terminal action (recommended) |

### Outbound (errors)

> **Confirm the exact topic string.** Two candidate forms have been seen; validate and set the final value:
- `business.direct-banking.cross-product.production-management.production-status.status-update`
- `business.direct-banking.cross-product-production-management.production-status.status-update`

| Field | Value |
|---|---|
| Topic | **PENDING** |
| Value format | Avro (via `org.apache.avro:avro-tools:1.12.0`) |
| Key | **PENDING** (suggest: `packageUniqueId` or `correlationId`) |
| Schema Registry URL | **PENDING** |
| Avro subject | **PENDING** |
| Compatibility | **PENDING** (recommend: BACKWARD) |

**Producer tuning (recommended starting points):**
```properties
acks=all
retries=3
delivery.timeout.ms=120000
linger.ms=10
batch.size=32768
max.in.flight.requests.per.connection=1
```

---

## AWS S3

| Field | Value |
|---|---|
| Bucket | **PENDING** |
| Incoming prefix | `incoming/` (confirm pattern) |
| Processed prefix | `processed/` |
| Secrets file | `/var/secrets/s3/s3cred.properties` |
| Region | **PENDING** |
| IAM role/profile | **PENDING** |
| SSE / KMS | **PENDING** (server-side encryption if used) |

**Key patterns (examples – confirm real ones):**
- Incoming: `incoming/<yyyy-MM-dd>/<packageUniqueId>.json.jwe` (**PENDING**)
- Processed: `processed/<yyyy-MM-dd>/<packageUniqueId>.json.jwe` (**PENDING**)

**Retries & timeouts (SDK):**
- Connect/read timeout: **PENDING** (recommend 3–5s)
- Retries: **PENDING** (recommend 3–5 with backoff)

---

## Database (PostgreSQL)

| Field | Value |
|---|---|
| JDBC URL | **PENDING** |
| Username | **PENDING** |
| Password | **PENDING** |
| Database | `cardpersodb` (confirm) |
| Schema | **PENDING** |
| Pool size | **PENDING** (recommend 10–20) |

**Suggested tables/constraints (fill actual names):**
```sql
-- Enforce idempotency on packageUniqueId
ALTER TABLE PENDING_TABLE
  ADD CONSTRAINT ux_package_unique_id UNIQUE (package_unique_id);
```

**Flyway:**
- Locations: **PENDING**
- Baseline: **PENDING**
- Repeatable migrations: **PENDING**

---

## Encryption / KMS (`JWECryptoUtil`)

| Key | Description |
|---|---|
| `kms-config.location` | Base path or URI to KMS/JWE config |
| `kms-config.jweCertificationActive` | Active certificate/key identifier |
| `kms-config.jweCertificationExpiring` | Expiring certificate/key identifier |
| `kms-config.jweCertificationExpired` | Expired certificate/key identifier |
| `kms-config.symetricKeyLocationActive` | Active symmetric key location |
| `kms-config.symetricKeyLocationExpired` | Expired symmetric key location |

**Operational notes:**
- Keep **rotation** documented (cadence, overlap windows).  
- Monitor decrypt failures (map to **9001**) and alert on spikes.  
- Validate payload **envelope** format (JWE/JWS) before attempting decrypt.

---

## Avro Contract (Outbound Error Event)

**Fields (recommended):**
| Field | Type | Required | Notes |
|---|---|---|---|
| `sourceService` | string | yes | e.g., `card-perso-validator-svc` |
| `correlationId` | string | yes | UUID |
| `packageUniqueId` | string | yes | Idempotency key |
| `errorCode` | string | yes | `9001`/`9002`/`9003`/`9006` |
| `errorMessage` | string | yes | Human-readable |
| `details` | record/map | no | Missing fields, rule name, etc. |
| `originalS3Key` | string | no | For traceability |
| `timestamp` | string | yes | ISO-8601 UTC |
| `env` | string | no | ENV tag |
| `region` | string | no | AWS region |

**Schema Registry:** URL **PENDING**, subject **PENDING**.  
**Compatibility:** **PENDING** (recommend BACKWARD).

---

## Security

- **Secrets**: mount-only; never log or commit (`/var/secrets/s3/s3cred.properties`, tokens).  
- **PII**: exclude from logs and outbound error payloads.  
- **Headers**: propagate `X-Correlation-Id`; scrub sensitive headers in logs.  
- **TLS**: enforce HTTPS for REST; verify certs (mTLS if required).

---

## Timeouts & Retries (Guidance)

| Integration | Connect | Read | Retries | Notes |
|---|---|---|---|---|
| `authapi` | 2–3s | 3–5s | 2 | Exponential backoff |
| `cardpersoapi` | 2–3s | 3–5s | 2 | Circuit breaker recommended |
| Kafka Producer | — | — | 3 | See producer properties |
| Kafka Consumer | — | — | — | Use backoff between polls on errors |
| S3/KMS | 3–5s | 3–5s | 3–5 | SDK-managed retries |

---

## Observability (per-integration)

- **REST**: log request ID, status code, latency. Emit `rest_client_requests_seconds` histograms.  
- **Kafka**: track consumer lag, publish success/failure counts.  
- **S3/KMS**: latency histograms, error counters by AWS error code.  
- **DB**: pool metrics, query timings.  
