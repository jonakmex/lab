# Deployment

This page documents how to build, configure and deploy the **Card Perso Validator Service** to Kubernetes using **Helm** and **Flyway**. All environment-specific values are marked as **PENDING**.

- **Runtime:** Java 21, Spring Boot 3.5.4 (embedded Tomcat 11.0.9)
- **Deployment:** Helm (Kubernetes), Flyway (DB migrations)
- **Secrets:** mounted file for S3 creds at `/var/secrets/s3/s3cred.properties` (or cloud-native IAM)
- **Main class:** `com.discover.cardfp.CardPersoValidatorSvcApplication`

---

## Release Workflow (Overview)

1. **Build & Test**
   - `./gradlew clean build`
   - `./gradlew test jacocoTestReport`
2. **Container Image**
   - Build multi-stage Docker image
   - Tag: `PENDING_REGISTRY/card-perso-validator-svc:<git-sha|semver>`
3. **DB Migrations (Flyway)**
   - Strategy A: App-managed on startup (simpler)
   - Strategy B: Pre-deploy **Job** (safer for blue/green/rollouts)
4. **Helm Upgrade**
   - `helm upgrade --install card-perso-validator ./chart -f values/<env>.yaml`
5. **Post-Deploy Checks**
   - Probes healthy, consumer lag, error rates (`9001/9002/9003/9006`)
6. **Rollback**
   - `helm rollback card-perso-validator <REV>` (ensure Flyway strategy is compatible)

---

## Containerization

### Dockerfile (multi-stage; distroless example)

```dockerfile
# --- Build stage
FROM gradle:8.9-jdk21 AS build
WORKDIR /app
COPY . .
RUN ./gradlew clean bootJar --no-daemon

# --- Runtime stage (distroless)
FROM gcr.io/distroless/java21-debian12:nonroot
WORKDIR /app
USER nonroot:nonroot
COPY --from=build /app/build/libs/*-SNAPSHOT.jar /app/app.jar
# Mount point for secrets (optional; k8s will bind)
VOLUME ["/var/secrets/s3"]
EXPOSE 8080
ENTRYPOINT ["java","-jar","/app/app.jar"]
```

> If you prefer a **JRE with shell** for debugging, use Eclipse Temurin base images. Keep `USER` non-root.

---

## Helm Chart Structure (suggested)

```
chart/
  Chart.yaml
  values.yaml
  templates/
    _helpers.tpl
    configmap.yaml
    secret.yaml
    deployment.yaml
    service.yaml
    ingress.yaml
    hpa.yaml
    pdb.yaml
    servicemonitor.yaml
    flyway-job.yaml           # optional (Strategy B)
```

---

## values.yaml (skeleton with placeholders)

```yaml
image:
  repository: PENDING_REGISTRY/card-perso-validator-svc
  tag: PENDING_TAG
  pullPolicy: IfNotPresent

replicaCount: 2

service:
  type: ClusterIP
  port: 8080

ingress:
  enabled: false
  className: PENDING
  hosts:
    - host: PENDING_HOST
      paths:
        - path: /
          pathType: Prefix
  tls:
    - hosts: [PENDING_HOST]
      secretName: PENDING_TLS_SECRET

resources:
  requests:
    cpu: "250m"
    memory: "512Mi"
  limits:
    cpu: "1000m"
    memory: "1Gi"

env:
  SPRING_PROFILES_ACTIVE: "prod"
  LOGGING_LEVEL_ROOT: "INFO"
  # Kafka
  KAFKA_BOOTSTRAP_SERVERS: "PENDING"
  KAFKA_CONSUMER_GROUP_ID: "PENDING"
  KAFKA_INPUT_TOPIC: "business.direct-banking.cross-product.production-management.card-fulfillment-processing.validation"
  KAFKA_ERROR_TOPIC: "PENDING"  # confirm exact
  # Schema registry (if used)
  SCHEMA_REGISTRY_URL: "PENDING"
  AVRO_SUBJECT: "PENDING"
  # DB
  SPRING_DATASOURCE_URL: "jdbc:postgresql://PENDING:5432/cardpersodb"
  SPRING_DATASOURCE_USERNAME: "PENDING"
  SPRING_DATASOURCE_PASSWORD: "PENDING"
  SPRING_JPA_DEFAULT_SCHEMA: "PENDING"
  # AWS/S3
  AWS_REGION: "PENDING"
  AWS_S3_BUCKET: "PENDING"
  AWS_S3_PREFIX_INCOMING: "incoming/"
  AWS_S3_PREFIX_PROCESSED: "processed/"
  AWS_SECRETS_FILE: "/var/secrets/s3/s3cred.properties"
  # KMS / JWE
  KMS_CONFIG_LOCATION: "PENDING"
  JWE_CERT_ACTIVE: "PENDING"
  JWE_CERT_EXPIRING: "PENDING"
  JWE_CERT_EXPIRED: "PENDING"
  SYM_KEY_ACTIVE: "PENDING"
  SYM_KEY_EXPIRED: "PENDING"

probes:
  livenessPath: /actuator/health/liveness
  readinessPath: /actuator/health/readiness
  startupPath: /actuator/health
  periodSeconds: 10
  timeoutSeconds: 2
  failureThreshold: 3
  initialDelaySeconds: 30

nodeSelector: {}
tolerations: []
affinity: {}

podSecurityContext:
  runAsNonRoot: true
  runAsUser: 65532
  runAsGroup: 65532
  fsGroup: 65532

containerSecurityContext:
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]

serviceAccount:
  create: true
  name: "card-perso-validator"
  annotations: {}

kafka:
  dlqTopic: "PENDING" # if any
  maxPollRecords: 100
  enableAutoCommit: false

flyway:
  strategy: "A" # A=app-startup, B=predeploy-job
  baselineOnMigrate: true
  locations: "classpath:db/migration"

monitoring:
  serviceMonitor:
    enabled: true
    interval: 30s
    scrapeTimeout: 10s
```

---

## deployment.yaml (key parts)

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ include "cpv.fullname" . }}
  labels: {{- include "cpv.labels" . | nindent 4 }}
spec:
  replicas: {{ .Values.replicaCount }}
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 0
  selector:
    matchLabels: {{- include "cpv.selectorLabels" . | nindent 6 }}
  template:
    metadata:
      labels: {{- include "cpv.selectorLabels" . | nindent 8 }}
      annotations:
        prometheus.io/scrape: "true"
        prometheus.io/path: "/actuator/prometheus"
        prometheus.io/port: "8080"
    spec:
      serviceAccountName: {{ include "cpv.serviceAccountName" . }}
      securityContext: {{- toYaml .Values.podSecurityContext | nindent 8 }}
      containers:
        - name: app
          image: "{{ .Values.image.repository }}:{{ .Values.image.tag }}"
          imagePullPolicy: {{ .Values.image.pullPolicy }}
          securityContext: {{- toYaml .Values.containerSecurityContext | nindent 12 }}
          ports:
            - containerPort: 8080
              name: http
          env:
            - name: SPRING_PROFILES_ACTIVE
              value: {{ .Values.env.SPRING_PROFILES_ACTIVE | quote }}
            - name: LOGGING_LEVEL_ROOT
              value: {{ .Values.env.LOGGING_LEVEL_ROOT | quote }}
            - name: KAFKA_BOOTSTRAP_SERVERS
              value: {{ .Values.env.KAFKA_BOOTSTRAP_SERVERS | quote }}
            - name: KAFKA_CONSUMER_GROUP_ID
              value: {{ .Values.env.KAFKA_CONSUMER_GROUP_ID | quote }}
            - name: KAFKA_INPUT_TOPIC
              value: {{ .Values.env.KAFKA_INPUT_TOPIC | quote }}
            - name: KAFKA_ERROR_TOPIC
              value: {{ .Values.env.KAFKA_ERROR_TOPIC | quote }}
            - name: SCHEMA_REGISTRY_URL
              value: {{ .Values.env.SCHEMA_REGISTRY_URL | quote }}
            - name: AVRO_SUBJECT
              value: {{ .Values.env.AVRO_SUBJECT | quote }}
            - name: SPRING_DATASOURCE_URL
              valueFrom:
                secretKeyRef:
                  name: {{ include "cpv.fullname" . }}-db
                  key: url
            - name: SPRING_DATASOURCE_USERNAME
              valueFrom:
                secretKeyRef:
                  name: {{ include "cpv.fullname" . }}-db
                  key: username
            - name: SPRING_DATASOURCE_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: {{ include "cpv.fullname" . }}-db
                  key: password
            - name: SPRING_JPA_PROPERTIES_HIBERNATE_DEFAULT_SCHEMA
              value: {{ .Values.env.SPRING_JPA_DEFAULT_SCHEMA | quote }}
            - name: AWS_REGION
              value: {{ .Values.env.AWS_REGION | quote }}
            - name: AWS_S3_BUCKET
              value: {{ .Values.env.AWS_S3_BUCKET | quote }}
            - name: AWS_S3_PREFIX_INCOMING
              value: {{ .Values.env.AWS_S3_PREFIX_INCOMING | quote }}
            - name: AWS_S3_PREFIX_PROCESSED
              value: {{ .Values.env.AWS_S3_PREFIX_PROCESSED | quote }}
            - name: AWS_SECRETS_FILE
              value: {{ .Values.env.AWS_SECRETS_FILE | quote }}
            - name: KMS_CONFIG_LOCATION
              value: {{ .Values.env.KMS_CONFIG_LOCATION | quote }}
            - name: JWE_CERT_ACTIVE
              value: {{ .Values.env.JWE_CERT_ACTIVE | quote }}
            - name: JWE_CERT_EXPIRING
              value: {{ .Values.env.JWE_CERT_EXPIRING | quote }}
            - name: JWE_CERT_EXPIRED
              value: {{ .Values.env.JWE_CERT_EXPIRED | quote }}
            - name: SYM_KEY_ACTIVE
              value: {{ .Values.env.SYM_KEY_ACTIVE | quote }}
            - name: SYM_KEY_EXPIRED
              value: {{ .Values.env.SYM_KEY_EXPIRED | quote }}
          volumeMounts:
            - name: s3-secrets
              mountPath: /var/secrets/s3
              readOnly: true
          readinessProbe:
            httpGet:
              path: {{ .Values.probes.readinessPath }}
              port: http
            periodSeconds: {{ .Values.probes.periodSeconds }}
            timeoutSeconds: {{ .Values.probes.timeoutSeconds }}
            failureThreshold: {{ .Values.probes.failureThreshold }}
            initialDelaySeconds: {{ .Values.probes.initialDelaySeconds }}
          livenessProbe:
            httpGet:
              path: {{ .Values.probes.livenessPath }}
              port: http
            periodSeconds: {{ .Values.probes.periodSeconds }}
          resources: {{- toYaml .Values.resources | nindent 12 }}
      volumes:
        - name: s3-secrets
          secret:
            secretName: {{ include "cpv.fullname" . }}-s3
            optional: true
```

---

## Secrets & Config

### DB Secret

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: {{ include "cpv.fullname" . }}-db
type: Opaque
stringData:
  url: "jdbc:postgresql://PENDING:5432/cardpersodb"
  username: "PENDING"
  password: "PENDING"
```

### S3 Creds Secret (optional if using IAM/IRSA)

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: {{ include "cpv.fullname" . }}-s3
type: Opaque
stringData:
  s3cred.properties: |
    aws.accessKeyId=PENDING
    aws.secretKey=PENDING
    aws.sessionToken=PENDING
```

> If on EKS with IRSA, prefer IAM role annotation on the ServiceAccount and omit static credentials.

---

## Service & Ingress

```yaml
apiVersion: v1
kind: Service
metadata:
  name: {{ include "cpv.fullname" . }}
spec:
  type: {{ .Values.service.type }}
  ports:
    - name: http
      port: {{ .Values.service.port }}
      targetPort: http
  selector: {{- include "cpv.selectorLabels" . | nindent 4 }}
```

```yaml
{{- if .Values.ingress.enabled }}
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: {{ include "cpv.fullname" . }}
  annotations: {}
spec:
  ingressClassName: {{ .Values.ingress.className }}
  tls:
    - hosts: {{ toYaml (pluck "hosts" .Values.ingress | first) | nindent 6 }}
      secretName: {{ .Values.ingress.tls | first | get "secretName" }}
  rules:
    - host: {{ .Values.ingress.hosts | first | get "host" }}
      http:
        paths:
          - path: {{ .Values.ingress.hosts | first | get "paths" | first | get "path" }}
            pathType: {{ .Values.ingress.hosts | first | get "paths" | first | get "pathType" }}
            backend:
              service:
                name: {{ include "cpv.fullname" . }}
                port:
                  number: {{ .Values.service.port }}
{{- end }}
```

---

## HPA (Autoscaling)

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: {{ include "cpv.fullname" . }}
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: {{ include "cpv.fullname" . }}
  minReplicas: 2
  maxReplicas: 6
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70
```

---

## Pod Disruption Budget

```yaml
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: {{ include "cpv.fullname" . }}-pdb
spec:
  minAvailable: 1
  selector:
    matchLabels: {{- include "cpv.selectorLabels" . | nindent 6 }}
```

---

## Observability (Prometheus)

```yaml
{{- if .Values.monitoring.serviceMonitor.enabled }}
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: {{ include "cpv.fullname" . }}
spec:
  selector:
    matchLabels: {{- include "cpv.selectorLabels" . | nindent 6 }}
  endpoints:
    - port: http
      path: /actuator/prometheus
      interval: {{ .Values.monitoring.serviceMonitor.interval }}
      scrapeTimeout: {{ .Values.monitoring.serviceMonitor.scrapeTimeout }}
{{- end }}
```

---

## Flyway Strategies

### Strategy A — App-managed (on startup)
- Enable via properties:
  ```yaml
  spring:
    flyway:
      enabled: true
      baseline-on-migrate: {{ .Values.flyway.baselineOnMigrate }}
      locations: {{ .Values.flyway.locations }}
  ```
- Pros: simple, fewer moving parts.  
- Cons: multiple replicas might race (Flyway handles locks, but startup delay possible).

### Strategy B — Pre-deploy Job (recommended for rollouts)

```yaml
apiVersion: batch/v1
kind: Job
metadata:
  name: {{ include "cpv.fullname" . }}-flyway
  annotations:
    "helm.sh/hook": pre-install,pre-upgrade
    "helm.sh/hook-delete-policy": before-hook-creation,hook-succeeded
spec:
  template:
    spec:
      serviceAccountName: {{ include "cpv.serviceAccountName" . }}
      restartPolicy: Never
      containers:
        - name: flyway
          image: flyway/flyway:10
          env:
            - name: FLYWAY_URL
              valueFrom:
                secretKeyRef:
                  name: {{ include "cpv.fullname" . }}-db
                  key: url
            - name: FLYWAY_USER
              valueFrom:
                secretKeyRef:
                  name: {{ include "cpv.fullname" . }}-db
                  key: username
            - name: FLYWAY_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: {{ include "cpv.fullname" . }}-db
                  key: password
          args:
            - -locations={{ .Values.flyway.locations }}
            - -baselineOnMigrate={{ .Values.flyway.baselineOnMigrate }}
            - migrate
```

> Ensure migrations are idempotent and compatible with rolling upgrades.

---

## Network Policies (optional but recommended)

- **Egress**: allow only Kafka, PostgreSQL, and AWS S3/KMS endpoints (or VPC endpoints).
- **Ingress**: restrict to cluster components needing access (if any).

---

## Readiness/Liveness

- Spring Boot probes already configured via Actuator endpoints in values above.

---

## Rollback & Disaster Recovery

- **Kafka**: consumer offsets and idempotency (`packageUniqueId`) prevent double-processing; verify DB unique constraint.
- **S3**: processed objects are immutable; use key versioning if enabled (**PENDING**).
- **DB**: Flyway maintains `schema_history`; rollback via new migrations (forward-only strategy recommended).

---

## Production Checklist

- [ ] All **PENDING** values filled (topics, registry, DB, S3, KMS).  
- [ ] **ServiceAccount/IRSA** configured (or secrets mounted).  
- [ ] **Resource requests/limits** tuned based on load tests.  
- [ ] **HPA** enabled with CPU and/or custom metrics.  
- [ ] **ServiceMonitor** integrated; alerts for `9001/9002/9006` spikes.  
- [ ] **DLQ** (if used) wired and documented.  
- [ ] **Schema Registry** compatibility set (if used).  
- [ ] **PDB** in place; surge/unavailable set for zero-downtime.  
